﻿using AutoMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Vendas.Application.Dtos.Request;
using Vendas.Application.Dtos.Response;
using Vendas.Application.Interfaces;
using Vendas.Application.Services;
using Vendas.Data.Filters;
using Vendas.Data.Interfaces;
using Vendas.Domain.Entities;
using Vendas.Domain.Messages;

namespace Vendas.Test.Services
{
    public class VendasServiceTest
    {
        private readonly IConfiguration _configuration;
        private ILoggerFactory _loggerFactory;

        public VendasServiceTest()
        {
            var mockLogger = new Mock<ILogger<VendasServico>>();

            mockLogger.Setup(
                m => m.Log(
                    LogLevel.Information,
                    It.IsAny<EventId>(),
                    It.IsAny<object>(),
                    It.IsAny<Exception>(),
                    It.IsAny<Func<object, Exception, string>>()));

            var mockLoggerFactory = new Mock<ILoggerFactory>();

            mockLoggerFactory.Setup(x => x.CreateLogger(It.IsAny<string>())).Returns(() => mockLogger.Object);

            _loggerFactory = mockLoggerFactory.Object;
        }

        [Fact]
        public async Task ShouldReturnSuccessInBuscarTodos()
        {
            var _mapperMock = new Mock<IMapper>();
            var _mockUnitOfWork = new Mock<IUnitOfWork>();
            var _mockVendasRepository = new Mock<IVendasRepositorio>();
            var _mockProdutosRepository = new Mock<IProdutoRepositorio>();
            var _mockItemsVendaRepository = new Mock<IItemsVendaRepositorio>();
            var _mockServiceBus = new Mock<IClientServiceBus>();
            var _vendaService = new VendasServico(_mapperMock.Object,
                this._loggerFactory, _mockUnitOfWork.Object,
                _mockVendasRepository.Object, _mockProdutosRepository.Object,
                _mockItemsVendaRepository.Object, _mockServiceBus.Object);

            var _vendasFilterExample = new VendasFilter()
            {
                DataFinal = Convert.ToDateTime("08/08/2024"),
                DataInicial = Convert.ToDateTime("01/08/2024"),
                ItemsPorPagina = 10,
                Pagina = 1
            };

            var _listVendas = new List<VendaEntidade>();

            _listVendas.Add(new VendaEntidade()
            {
                Id = Guid.Parse("FA5BD528-9D7C-4EB4-84A2-AA31E00BC3D1"),
                ClienteEntidadeId = Guid.Parse("412f69d7-3f38-497e-a48e-ae73fad15d51"),
                DataVenda = Convert.ToDateTime("08/08/2024"),
                FilialEntidadeId = Guid.Parse("7ed488de-2695-4fda-86cd-ce9ef9361070"),
                Status = Domain.Enums.StatusVenda.SVCriada,
                Items = new List<ItemVendaEntidade>()
                    {
                        new ItemVendaEntidade()
                        {
                             Id = Guid.NewGuid(),
                             ProdutoEntidadeId = Guid.Parse("db473c6d-3fb5-44aa-a452-e4231071a6bf"),
                             Quantidade = 10,
                             Status = Domain.Enums.StatusItemVenda.SIVNaoCancelado,
                             ValorUnitario = 10
                        }
                    }
            });

            var _dataVendasResponse = new VendaDataResponse();
            var _listVendasResponse = new List<VendaResponse>()
            {
                new VendaResponse()
                {
                     ClienteEntidadeId = Guid.Parse("412f69d7-3f38-497e-a48e-ae73fad15d51"),
                     DataVenda = Convert.ToDateTime("08/08/2024"),
                     FilialEntidadeId = Guid.Parse("7ed488de-2695-4fda-86cd-ce9ef9361070"),
                     Id = Guid.Parse("FA5BD528-9D7C-4EB4-84A2-AA31E00BC3D1"),
                     ValorTotal = 150,
                     Items = new List<ItemVendaResponse>()
                     {
                         new ItemVendaResponse()
                         {
                              Id = Guid.NewGuid(),
                              ProdutoEntidadeId = Guid.Parse("db473c6d-3fb5-44aa-a452-e4231071a6bf"),
                              Quantidade = 10,
                              ValorUnitario = 15,
                              Desconto = 0,
                              ValorTotal = 150
                         }
                     }
                }
            };

            _dataVendasResponse.Data = _listVendasResponse;

            var _paginatedEntity = new PaginatedEntity<VendaEntidade>
            {
                Items = _listVendas,
                TotalRegistros = _listVendas.Count
            };

            var _cancellation = new CancellationToken();

            _mockVendasRepository.Setup(x => x.BuscarTodoAsync(_vendasFilterExample, _cancellation)).ReturnsAsync(_paginatedEntity);
            _mapperMock.Setup(m => m.Map<List<VendaResponse>>(_listVendas)).Returns(_listVendasResponse);

            // Act
            var result = await _vendaService.BuscarTodosAsync(_vendasFilterExample, _cancellation);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(1, result.Data.TotalRegistros);
        }

        [Fact]
        public async Task ShouldReturnFailInBuscarTodos()
        {
            var _mapperMock = new Mock<IMapper>();
            var _mockUnitOfWork = new Mock<IUnitOfWork>();
            var _mockVendasRepository = new Mock<IVendasRepositorio>();
            var _mockProdutosRepository = new Mock<IProdutoRepositorio>();
            var _mockItemsVendaRepository = new Mock<IItemsVendaRepositorio>();
            var _mockServiceBus = new Mock<IClientServiceBus>();
            var _vendaService = new VendasServico(_mapperMock.Object,
                this._loggerFactory, _mockUnitOfWork.Object,
                _mockVendasRepository.Object, _mockProdutosRepository.Object,
                _mockItemsVendaRepository.Object, _mockServiceBus.Object);

            var _vendasFilterExample = new VendasFilter()
            {
                DataFinal = Convert.ToDateTime("08/08/2024"),
                DataInicial = Convert.ToDateTime("01/08/2024"),
                ItemsPorPagina = 10,
                Pagina = 1
            };

            var _listVendas = new List<VendaEntidade>();
            var _dataVendasResponse = new VendaDataResponse();
            var _listVendasResponse = new List<VendaResponse>();

            _dataVendasResponse.Data = _listVendasResponse;

            var _paginatedEntity = new PaginatedEntity<VendaEntidade>
            {
                Items = _listVendas,
                TotalRegistros = _listVendas.Count
            };

            var _cancellation = new CancellationToken();

            _mockVendasRepository.Setup(x => x.BuscarTodoAsync(_vendasFilterExample, _cancellation)).ReturnsAsync(_paginatedEntity);
            _mapperMock.Setup(m => m.Map<List<VendaResponse>>(_listVendas)).Returns(_listVendasResponse);

            // Act
            var result = await _vendaService.BuscarTodosAsync(_vendasFilterExample, _cancellation);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Error.Message == "Não foi encontrada nenhuma venda");
        }

        [Fact]
        public async Task ShouldReturnSuccessInBuscarPorId()
        {
            var _mapperMock = new Mock<IMapper>();
            var _mockUnitOfWork = new Mock<IUnitOfWork>();
            var _mockVendasRepository = new Mock<IVendasRepositorio>();
            var _mockProdutosRepository = new Mock<IProdutoRepositorio>();
            var _mockItemsVendaRepository = new Mock<IItemsVendaRepositorio>();
            var _mockServiceBus = new Mock<IClientServiceBus>();
            var _vendaService = new VendasServico(_mapperMock.Object,
                this._loggerFactory, _mockUnitOfWork.Object,
                _mockVendasRepository.Object, _mockProdutosRepository.Object,
                _mockItemsVendaRepository.Object, _mockServiceBus.Object);

            var _id = Guid.Parse("FA5BD528-9D7C-4EB4-84A2-AA31E00BC3D1");
            var _vendaEntidade = new VendaEntidade()
            {
                Id = _id,
                ClienteEntidadeId = Guid.Parse("412f69d7-3f38-497e-a48e-ae73fad15d51"),
                DataVenda = Convert.ToDateTime("08/08/2024"),
                FilialEntidadeId = Guid.Parse("7ed488de-2695-4fda-86cd-ce9ef9361070"),
                Status = Domain.Enums.StatusVenda.SVCriada,
                Items = new List<ItemVendaEntidade>()
                    {
                        new ItemVendaEntidade()
                        {
                             Id = Guid.NewGuid(),
                             ProdutoEntidadeId = Guid.Parse("db473c6d-3fb5-44aa-a452-e4231071a6bf"),
                             Quantidade = 10,
                             Status = Domain.Enums.StatusItemVenda.SIVNaoCancelado,
                             ValorUnitario = 10
                        }
                    }
            };

            var _vendaResponse = new VendaResponse()
            {
                ClienteEntidadeId = Guid.Parse("412f69d7-3f38-497e-a48e-ae73fad15d51"),
                DataVenda = Convert.ToDateTime("08/08/2024"),
                FilialEntidadeId = Guid.Parse("7ed488de-2695-4fda-86cd-ce9ef9361070"),
                Id = _id,
                ValorTotal = 150,
                Items = new List<ItemVendaResponse>()
                     {
                         new ItemVendaResponse()
                         {
                              Id = Guid.NewGuid(),
                              ProdutoEntidadeId = Guid.Parse("db473c6d-3fb5-44aa-a452-e4231071a6bf"),
                              Quantidade = 10,
                              ValorUnitario = 15,
                              Desconto = 0,
                              ValorTotal = 150
                         }
                     }
            };

            var _cancellation = new CancellationToken();

            _mockVendasRepository.Setup(x => x.BuscarPorId(It.IsAny<Guid>(), _cancellation)).ReturnsAsync(_vendaEntidade);
            _mapperMock.Setup(m => m.Map<VendaResponse>(_vendaEntidade)).Returns(_vendaResponse);

            // Act
            var result = await _vendaService.BuscarPorIdAsync(_id, _cancellation);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Data.Id == _id);
        }

        [Fact]
        public async Task ShouldReturnFailureInBuscarPorId()
        {
            var _mapperMock = new Mock<IMapper>();
            var _mockUnitOfWork = new Mock<IUnitOfWork>();
            var _mockVendasRepository = new Mock<IVendasRepositorio>();
            var _mockProdutosRepository = new Mock<IProdutoRepositorio>();
            var _mockItemsVendaRepository = new Mock<IItemsVendaRepositorio>();
            var _mockServiceBus = new Mock<IClientServiceBus>();
            var _vendaService = new VendasServico(_mapperMock.Object,
                this._loggerFactory, _mockUnitOfWork.Object,
                _mockVendasRepository.Object, _mockProdutosRepository.Object,
                _mockItemsVendaRepository.Object, _mockServiceBus.Object);

            var _id = Guid.Parse("FA5BD528-9D7C-4EB4-84A2-AA31E00BC3D1");
            VendaEntidade _vendaEntidadeNula = null;
            var _vendaEntidade = new VendaEntidade()
            {
                Id = _id,
                ClienteEntidadeId = Guid.Parse("412f69d7-3f38-497e-a48e-ae73fad15d51"),
                DataVenda = Convert.ToDateTime("08/08/2024"),
                FilialEntidadeId = Guid.Parse("7ed488de-2695-4fda-86cd-ce9ef9361070"),
                Status = Domain.Enums.StatusVenda.SVCriada,
                Items = new List<ItemVendaEntidade>()
                    {
                        new ItemVendaEntidade()
                        {
                             Id = Guid.NewGuid(),
                             ProdutoEntidadeId = Guid.Parse("db473c6d-3fb5-44aa-a452-e4231071a6bf"),
                             Quantidade = 10,
                             Status = Domain.Enums.StatusItemVenda.SIVNaoCancelado,
                             ValorUnitario = 10
                        }
                    }
            };

            var _vendaResponse = new VendaResponse()
            {
                ClienteEntidadeId = Guid.Parse("412f69d7-3f38-497e-a48e-ae73fad15d51"),
                DataVenda = Convert.ToDateTime("08/08/2024"),
                FilialEntidadeId = Guid.Parse("7ed488de-2695-4fda-86cd-ce9ef9361070"),
                Id = _id,
                ValorTotal = 150,
                Items = new List<ItemVendaResponse>()
                     {
                         new ItemVendaResponse()
                         {
                              Id = Guid.NewGuid(),
                              ProdutoEntidadeId = Guid.Parse("db473c6d-3fb5-44aa-a452-e4231071a6bf"),
                              Quantidade = 10,
                              ValorUnitario = 15,
                              Desconto = 0,
                              ValorTotal = 150
                         }
                     }
            };

            var _cancellation = new CancellationToken();

            _mockVendasRepository.Setup(x => x.BuscarPorId(It.IsAny<Guid>(), _cancellation)).ReturnsAsync(_vendaEntidadeNula);
            _mapperMock.Setup(m => m.Map<VendaResponse>(_vendaEntidade)).Returns(_vendaResponse);

            // Act
            var result = await _vendaService.BuscarPorIdAsync(_id, _cancellation);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Error.Message == "Não foi encontrada nenhuma venda com o Id informado");
        }

        [Fact]
        public async Task ShouldReturnSuccessInCriar()
        {
            var _mapperMock = new Mock<IMapper>();
            var _mockUnitOfWork = new Mock<IUnitOfWork>();
            var _mockVendasRepository = new Mock<IVendasRepositorio>();
            var _mockProdutosRepository = new Mock<IProdutoRepositorio>();
            var _mockItemsVendaRepository = new Mock<IItemsVendaRepositorio>();
            var _mockServiceBus = new Mock<IClientServiceBus>();
            var _vendaService = new VendasServico(_mapperMock.Object,
                this._loggerFactory, _mockUnitOfWork.Object,
                _mockVendasRepository.Object, _mockProdutosRepository.Object,
                _mockItemsVendaRepository.Object, _mockServiceBus.Object);

            var _id = Guid.Parse("FA5BD528-9D7C-4EB4-84A2-AA31E00BC3D1");
            var _vendaEntidade = new VendaEntidade()
            {
                Id = _id,
                ClienteEntidadeId = Guid.Parse("412f69d7-3f38-497e-a48e-ae73fad15d51"),
                DataVenda = Convert.ToDateTime("08/08/2024"),
                FilialEntidadeId = Guid.Parse("7ed488de-2695-4fda-86cd-ce9ef9361070"),
                Status = Domain.Enums.StatusVenda.SVCriada,
                Items = new List<ItemVendaEntidade>()
                    {
                        new ItemVendaEntidade()
                        {
                             Id = Guid.NewGuid(),
                             ProdutoEntidadeId = Guid.Parse("db473c6d-3fb5-44aa-a452-e4231071a6bf"),
                             Quantidade = 10,
                             Status = Domain.Enums.StatusItemVenda.SIVNaoCancelado,
                             ValorUnitario = 10
                        }
                    }
            };

            var _criarVendaRequest = new CriarVendaRequest()
            {
                ClienteId = Guid.Parse("412f69d7-3f38-497e-a48e-ae73fad15d51"),
                DataVenda = Convert.ToDateTime("28/09/2024"),
                FilialId = Guid.Parse("7ed488de-2695-4fda-86cd-ce9ef9361070"),
                Items = new List<ItemVendaRequest>()
                    {
                         new ItemVendaRequest()
                         {
                              ProdutoId = Guid.Parse("db473c6d-3fb5-44aa-a452-e4231071a6bf"),
                              Quantidade = 10,
                              ValorUnitario = 10
                         }
                    }
            };

            var _idVendaResponse = Guid.Parse("B9856461-C8BD-4923-BC15-CED73B5CB583");
            var _createVendaResponse = new CreateVendaResponse()
            {
                Id = _idVendaResponse
            };

            var _produtoEntidade = new ProdutoEntidade()
            {
                Id = Guid.Parse("db473c6d-3fb5-44aa-a452-e4231071a6bf"),
                Nome = "Arroz",
                Quantidade = 100,
                ValorUnitario = 10
            };

            var _cancellation = new CancellationToken();

            _mockVendasRepository.Setup(x => x.InserirAsync(It.IsAny<VendaEntidade>(), _cancellation)).ReturnsAsync(_vendaEntidade);
            _mockProdutosRepository.Setup(x => x.BuscaPorIdAsync(It.IsAny<Guid>(), _cancellation)).ReturnsAsync(_produtoEntidade);
            _mockProdutosRepository.Setup(x => x.AtualizarAsync(It.IsAny<ProdutoEntidade>(), _cancellation)).ReturnsAsync(_produtoEntidade);
            _mapperMock.Setup(m => m.Map<CreateVendaResponse>(_vendaEntidade)).Returns(_createVendaResponse);
            _mockServiceBus.Setup(m => m.EnviarMensagemAsync(It.IsAny<MensagemVendaCriada>()));

            // Act
            var result = await _vendaService.CriarAsync(_criarVendaRequest, _cancellation);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Data.Id == _idVendaResponse);
        }

        [Fact]
        public async Task ShouldReturnFailureInCriarWithItemsVazio()
        {
            var _mapperMock = new Mock<IMapper>();
            var _mockUnitOfWork = new Mock<IUnitOfWork>();
            var _mockVendasRepository = new Mock<IVendasRepositorio>();
            var _mockProdutosRepository = new Mock<IProdutoRepositorio>();
            var _mockItemsVendaRepository = new Mock<IItemsVendaRepositorio>();
            var _mockServiceBus = new Mock<IClientServiceBus>();
            var _vendaService = new VendasServico(_mapperMock.Object,
                this._loggerFactory, _mockUnitOfWork.Object,
                _mockVendasRepository.Object, _mockProdutosRepository.Object,
                _mockItemsVendaRepository.Object, _mockServiceBus.Object);

            var _id = Guid.Parse("FA5BD528-9D7C-4EB4-84A2-AA31E00BC3D1");
            var _vendaEntidade = new VendaEntidade()
            {
                Id = _id,
                ClienteEntidadeId = Guid.Parse("412f69d7-3f38-497e-a48e-ae73fad15d51"),
                DataVenda = Convert.ToDateTime("08/08/2024"),
                FilialEntidadeId = Guid.Parse("7ed488de-2695-4fda-86cd-ce9ef9361070"),
                Status = Domain.Enums.StatusVenda.SVCriada,
                Items = new List<ItemVendaEntidade>()
            };

            var _criarVendaRequest = new CriarVendaRequest()
            {
                ClienteId = Guid.Parse("412f69d7-3f38-497e-a48e-ae73fad15d51"),
                DataVenda = Convert.ToDateTime("28/09/2024"),
                FilialId = Guid.Parse("7ed488de-2695-4fda-86cd-ce9ef9361070"),
                Items = new List<ItemVendaRequest>()
            };

            var _idVendaResponse = Guid.Parse("B9856461-C8BD-4923-BC15-CED73B5CB583");
            var _createVendaResponse = new CreateVendaResponse()
            {
                Id = _idVendaResponse
            };

            var _produtoEntidade = new ProdutoEntidade()
            {
                Id = Guid.Parse("db473c6d-3fb5-44aa-a452-e4231071a6bf"),
                Nome = "Arroz",
                Quantidade = 100,
                ValorUnitario = 10
            };

            var _cancellation = new CancellationToken();

            _mockVendasRepository.Setup(x => x.InserirAsync(It.IsAny<VendaEntidade>(), _cancellation)).ReturnsAsync(_vendaEntidade);
            _mockProdutosRepository.Setup(x => x.BuscaPorIdAsync(It.IsAny<Guid>(), _cancellation)).ReturnsAsync(_produtoEntidade);
            _mockProdutosRepository.Setup(x => x.AtualizarAsync(It.IsAny<ProdutoEntidade>(), _cancellation)).ReturnsAsync(_produtoEntidade);
            _mapperMock.Setup(m => m.Map<CreateVendaResponse>(_vendaEntidade)).Returns(_createVendaResponse);
            _mockServiceBus.Setup(m => m.EnviarMensagemAsync(It.IsAny<MensagemVendaCriada>()));

            // Act
            var result = await _vendaService.CriarAsync(_criarVendaRequest, _cancellation);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Error.Message == "Items - A lista de item deve ter pelo menos um registro.");
        }

        [Fact]
        public async Task ShouldReturnFailureInCriarProdutoQuantidadeInsuficiente()
        {
            var _mapperMock = new Mock<IMapper>();
            var _mockUnitOfWork = new Mock<IUnitOfWork>();
            var _mockVendasRepository = new Mock<IVendasRepositorio>();
            var _mockProdutosRepository = new Mock<IProdutoRepositorio>();
            var _mockItemsVendaRepository = new Mock<IItemsVendaRepositorio>();
            var _mockServiceBus = new Mock<IClientServiceBus>();
            var _vendaService = new VendasServico(_mapperMock.Object,
                this._loggerFactory, _mockUnitOfWork.Object,
                _mockVendasRepository.Object, _mockProdutosRepository.Object,
                _mockItemsVendaRepository.Object, _mockServiceBus.Object);

            var _id = Guid.Parse("FA5BD528-9D7C-4EB4-84A2-AA31E00BC3D1");
            var _vendaEntidade = new VendaEntidade()
            {
                Id = _id,
                ClienteEntidadeId = Guid.Parse("412f69d7-3f38-497e-a48e-ae73fad15d51"),
                DataVenda = Convert.ToDateTime("08/08/2024"),
                FilialEntidadeId = Guid.Parse("7ed488de-2695-4fda-86cd-ce9ef9361070"),
                Status = Domain.Enums.StatusVenda.SVCriada,
                Items = new List<ItemVendaEntidade>()
                    {
                        new ItemVendaEntidade()
                        {
                             Id = Guid.NewGuid(),
                             ProdutoEntidadeId = Guid.Parse("db473c6d-3fb5-44aa-a452-e4231071a6bf"),
                             Quantidade = 10,
                             Status = Domain.Enums.StatusItemVenda.SIVNaoCancelado,
                             ValorUnitario = 10
                        }
                    }
            };

            var _criarVendaRequest = new CriarVendaRequest()
            {
                ClienteId = Guid.Parse("412f69d7-3f38-497e-a48e-ae73fad15d51"),
                DataVenda = Convert.ToDateTime("28/09/2024"),
                FilialId = Guid.Parse("7ed488de-2695-4fda-86cd-ce9ef9361070"),
                Items = new List<ItemVendaRequest>()
                    {
                         new ItemVendaRequest()
                         {
                              ProdutoId = Guid.Parse("db473c6d-3fb5-44aa-a452-e4231071a6bf"),
                              Quantidade = 20,
                              ValorUnitario = 10
                         }
                    }
            };

            var _idVendaResponse = Guid.Parse("B9856461-C8BD-4923-BC15-CED73B5CB583");
            var _createVendaResponse = new CreateVendaResponse()
            {
                Id = _idVendaResponse
            };

            var _produtoEntidade = new ProdutoEntidade()
            {
                Id = Guid.Parse("db473c6d-3fb5-44aa-a452-e4231071a6bf"),
                Nome = "Arroz",
                Quantidade = 10,
                ValorUnitario = 10
            };

            var _cancellation = new CancellationToken();

            _mockVendasRepository.Setup(x => x.InserirAsync(It.IsAny<VendaEntidade>(), _cancellation)).ReturnsAsync(_vendaEntidade);
            _mockProdutosRepository.Setup(x => x.BuscaPorIdAsync(It.IsAny<Guid>(), _cancellation)).ReturnsAsync(_produtoEntidade);
            _mockProdutosRepository.Setup(x => x.AtualizarAsync(It.IsAny<ProdutoEntidade>(), _cancellation)).ReturnsAsync(_produtoEntidade);
            _mapperMock.Setup(m => m.Map<CreateVendaResponse>(_vendaEntidade)).Returns(_createVendaResponse);
            _mockServiceBus.Setup(m => m.EnviarMensagemAsync(It.IsAny<MensagemVendaCriada>()));

            // Act
            var result = await _vendaService.CriarAsync(_criarVendaRequest, _cancellation);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Error.Message == "A quantidade informada  é superior ao disponível");
        }

        [Fact]
        public async Task ShouldReturnSuccessInCancelar()
        {
            var _mapperMock = new Mock<IMapper>();
            var _mockUnitOfWork = new Mock<IUnitOfWork>();
            var _mockVendasRepository = new Mock<IVendasRepositorio>();
            var _mockProdutosRepository = new Mock<IProdutoRepositorio>();
            var _mockItemsVendaRepository = new Mock<IItemsVendaRepositorio>();
            var _mockServiceBus = new Mock<IClientServiceBus>();
            var _vendaService = new VendasServico(_mapperMock.Object,
                this._loggerFactory, _mockUnitOfWork.Object,
                _mockVendasRepository.Object, _mockProdutosRepository.Object,
                _mockItemsVendaRepository.Object, _mockServiceBus.Object);

            var _id = Guid.Parse("FA5BD528-9D7C-4EB4-84A2-AA31E00BC3D1");
            var _vendaEntidade = new VendaEntidade()
            {
                Id = _id,
                ClienteEntidadeId = Guid.Parse("412f69d7-3f38-497e-a48e-ae73fad15d51"),
                DataVenda = Convert.ToDateTime("08/08/2024"),
                FilialEntidadeId = Guid.Parse("7ed488de-2695-4fda-86cd-ce9ef9361070"),
                Status = Domain.Enums.StatusVenda.SVCriada,
                Items = new List<ItemVendaEntidade>()
                    {
                        new ItemVendaEntidade()
                        {
                             Id = Guid.NewGuid(),
                             ProdutoEntidadeId = Guid.Parse("db473c6d-3fb5-44aa-a452-e4231071a6bf"),
                             Quantidade = 10,
                             Status = Domain.Enums.StatusItemVenda.SIVNaoCancelado,
                             ValorUnitario = 10
                        }
                    }
            };

            var _itemVendaEntidade = new ItemVendaEntidade()
            {
                Id = Guid.NewGuid(),
                ProdutoEntidadeId = Guid.Parse("db473c6d-3fb5-44aa-a452-e4231071a6bf"),
                Quantidade = 10,
                Status = Domain.Enums.StatusItemVenda.SIVNaoCancelado,
                ValorUnitario = 10
            };

            var _idVendaResponse = Guid.Parse("B9856461-C8BD-4923-BC15-CED73B5CB583");
            var _cancelarVendaResponse = new CancelarVendaResponse()
            {
                Id = _idVendaResponse
            };

            var _cancelarVendaRequest = new CancelarVendaRequest()
            {
                Id = _idVendaResponse
            };

            var _produtoEntidade = new ProdutoEntidade()
            {
                Id = Guid.Parse("db473c6d-3fb5-44aa-a452-e4231071a6bf"),
                Nome = "Arroz",
                Quantidade = 100,
                ValorUnitario = 10
            };

            var _cancellation = new CancellationToken();

            _mockVendasRepository.Setup(x => x.BuscarPorId(It.IsAny<Guid>(), _cancellation)).ReturnsAsync(_vendaEntidade);
            _mockVendasRepository.Setup(x => x.AtualizarAsync(It.IsAny<VendaEntidade>(), _cancellation)).ReturnsAsync(_vendaEntidade);
            _mockProdutosRepository.Setup(x => x.BuscaPorIdAsync(It.IsAny<Guid>(), _cancellation)).ReturnsAsync(_produtoEntidade);
            _mockProdutosRepository.Setup(x => x.AtualizarAsync(It.IsAny<ProdutoEntidade>(), _cancellation)).ReturnsAsync(_produtoEntidade);
            _mockItemsVendaRepository.Setup(x => x.AtualizarAsync(It.IsAny<ItemVendaEntidade>(), _cancellation)).ReturnsAsync(_itemVendaEntidade);
            _mapperMock.Setup(m => m.Map<CancelarVendaResponse>(_vendaEntidade)).Returns(_cancelarVendaResponse);
            _mockServiceBus.Setup(m => m.EnviarMensagemAsync(It.IsAny<MensagemVendaCriada>()));

            // Act
            var result = await _vendaService.CancelarAsync(_cancelarVendaRequest, _cancellation);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Data.Id == _idVendaResponse);
        }

        [Fact]
        public async Task ShouldReturnSuccessInFechar()
        {
            var _mapperMock = new Mock<IMapper>();
            var _mockUnitOfWork = new Mock<IUnitOfWork>();
            var _mockVendasRepository = new Mock<IVendasRepositorio>();
            var _mockProdutosRepository = new Mock<IProdutoRepositorio>();
            var _mockItemsVendaRepository = new Mock<IItemsVendaRepositorio>();
            var _mockServiceBus = new Mock<IClientServiceBus>();
            var _vendaService = new VendasServico(_mapperMock.Object,
                this._loggerFactory, _mockUnitOfWork.Object,
                _mockVendasRepository.Object, _mockProdutosRepository.Object,
                _mockItemsVendaRepository.Object,_mockServiceBus.Object);

            var _id = Guid.Parse("FA5BD528-9D7C-4EB4-84A2-AA31E00BC3D1");
            var _vendaEntidade = new VendaEntidade()
            {
                Id = _id,
                ClienteEntidadeId = Guid.Parse("412f69d7-3f38-497e-a48e-ae73fad15d51"),
                DataVenda = Convert.ToDateTime("08/08/2024"),
                FilialEntidadeId = Guid.Parse("7ed488de-2695-4fda-86cd-ce9ef9361070"),
                Status = Domain.Enums.StatusVenda.SVCriada,
                Items = new List<ItemVendaEntidade>()
                    {
                        new ItemVendaEntidade()
                        {
                             Id = Guid.NewGuid(),
                             ProdutoEntidadeId = Guid.Parse("db473c6d-3fb5-44aa-a452-e4231071a6bf"),
                             Quantidade = 10,
                             Status = Domain.Enums.StatusItemVenda.SIVNaoCancelado,
                             ValorUnitario = 10
                        }
                    }
            };

            var _idVendaResponse = Guid.Parse("B9856461-C8BD-4923-BC15-CED73B5CB583");
            var _fecharVendaResponse = new FecharVendaResponse()
            {
                Id = _idVendaResponse
            };

            var _fecharVendaRequest = new FecharVendaRequest()
            {
                Id = _idVendaResponse
            };

            var _cancellation = new CancellationToken();

            _mockVendasRepository.Setup(x => x.BuscarPorId(It.IsAny<Guid>(), _cancellation)).ReturnsAsync(_vendaEntidade);
            _mockVendasRepository.Setup(x => x.AtualizarAsync(It.IsAny<VendaEntidade>(), _cancellation)).ReturnsAsync(_vendaEntidade);
            _mapperMock.Setup(m => m.Map<FecharVendaResponse>(_vendaEntidade)).Returns(_fecharVendaResponse);
            _mockServiceBus.Setup(m => m.EnviarMensagemAsync(It.IsAny<MensagemVendaCriada>()));

            // Act
            var result = await _vendaService.FecharAsync(_fecharVendaRequest, _cancellation);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Data.Id == _idVendaResponse);
        }
    }
}