﻿using VendaAPI.Configurations;
using Vendas.Ioc;

namespace VendaAPI
{
    public static class Startup
    {
        public static IServiceCollection ConfigureServices(this IServiceCollection services, 
            IConfiguration configuration, IWebHostEnvironment webHostEnvironment)
        {
            services.AddCors(options =>
            {
                options.AddPolicy("AllowSpecificOrigins", builder => builder
                                      .WithOrigins("*")
                                      .AllowAnyHeader()
                                      .AllowAnyMethod());
            });

            services.AddControllers();
            services.AddServices(configuration);
            services.AddSwaggerConfiguration();

            services.Configure<RouteOptions>(options =>
            {
                options.LowercaseUrls = true;
            });

            return services;
        }

        public static WebApplication Configure(this WebApplication app)
        {
            app.UseCors("AllowSpecificOrigins");
            app.UseSwagger();
            app.UseSwaggerUI(options =>
            {
                options.DocumentTitle = "Sistema de Vendas";
            });

            app.UseHttpsRedirection();
            app.MapControllers();
            app.AddMigration();

            return app;
        }
    }
}