﻿using Microsoft.AspNetCore.Mvc;
using Vendas.Application.Dtos.Request;
using Vendas.Application.Dtos.Response;
using Vendas.Application.Interfaces;
using Vendas.Data.Filters;
using Vendas.Domain.Extensions;

namespace VendaAPI.Controllers
{
    [Route("v1/vendas")]
    [ApiController]
    public class VendasController : Controller
    {
        private readonly IVendasServico _vendasService;

        public VendasController(IVendasServico vendasService)
        {
            _vendasService = vendasService;
        }

        /// <summary>
        /// Retorna uma venda
        /// </summary>
        /// <response code="200">Retorna uma venda</response>
        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(VendaResponse))]
        public async Task<IActionResult> BuscarPorIdAsync(Guid id, CancellationToken cancellationToken)
        {
            var response = await _vendasService.BuscarPorIdAsync(id, cancellationToken);

            return response.Match(
              onSuccess: Ok,
              onFailure: error => error.ToHttpResponseError());
        }

        /// <summary>
        /// Retorna todas as vendas
        /// </summary>
        /// <response code="200">Retorna uma lista de vendas</response>
        [HttpPost("all")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(VendaDataResponse))]
        public async Task<IActionResult> BuscarTodosAsync([FromBody] VendasFilter filter, CancellationToken cancellationToken)
        {
            var response = await _vendasService.BuscarTodosAsync(filter, cancellationToken);

            return response.Match(
              onSuccess: Ok,
              onFailure: error => error.ToHttpResponseError());
        }

        /// <summary>
        /// Cria uma venda
        /// </summary>
        /// <response code="200">Retorna id da venda criada</response>
        [HttpPost("criar")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CreateVendaResponse))]
        public async Task<IActionResult> CriarAsync([FromBody] CriarVendaRequest request, CancellationToken cancellationToken)
        {
            var response = await _vendasService.CriarAsync(request, cancellationToken);

            return response.Match(
              onSuccess: Ok,
              onFailure: error => error.ToHttpResponseError());
        }

        /// <summary>
        /// Cancela uma venda
        /// </summary>
        /// <response code="200">Retorna id da venda criada</response>
        [HttpPost("cancelar")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(CancelarVendaResponse))]
        public async Task<IActionResult> CancelarAsync([FromForm] CancelarVendaRequest request, CancellationToken cancellationToken)
        {
            var response = await _vendasService.CancelarAsync(request, cancellationToken);

            return response.Match(
              onSuccess: Ok,
              onFailure: error => error.ToHttpResponseError());
        }

        /// <summary>
        /// Fechar venda
        /// </summary>
        /// <response code="200">Retorna id da venda fechada</response>
        [HttpPost("fechar")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(FecharVendaResponse))]
        public async Task<IActionResult> FecharAsync([FromForm] FecharVendaRequest request, CancellationToken cancellationToken)
        {
            var response = await _vendasService.FecharAsync(request, cancellationToken);

            return response.Match(
              onSuccess: Ok,
              onFailure: error => error.ToHttpResponseError());
        }
    }
}
