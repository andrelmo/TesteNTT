﻿using Microsoft.EntityFrameworkCore;
using System.Diagnostics.CodeAnalysis;
using Vendas.Data;

namespace VendaAPI.Configurations
{
    [ExcludeFromCodeCoverage]
    public static class MigrationConfiguration
    {
        public static void AddMigration(this WebApplication app)
        {
            app.UseMiddleware<Vendas.ControllerHandler.ControllerHandler>();

            using (var scope = app.Services.CreateScope())
            {
                var dbContext = scope.ServiceProvider.GetRequiredService<VendasContext>();
                dbContext.Database.Migrate();
            }
        }
    }
}
