﻿namespace Vendas.ControllerHandler.ValueObjects
{
    public abstract class Error
    {
        public string Message { get; protected init; } = null!;
    }
}
