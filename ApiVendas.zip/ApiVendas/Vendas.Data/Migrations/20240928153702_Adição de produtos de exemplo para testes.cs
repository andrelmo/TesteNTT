﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Vendas.Data.Migrations
{
    /// <inheritdoc />
    public partial class Adiçãodeprodutosdeexemploparatestes : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "produtos",
                columns: new[] { "id", "nome", "data_criacao", "valorunitario","quantidade" },
                values: new object[,]
                {
                    { "BD577EA0-E10C-4307-937B-F794B76B803B", "Limpol",DateTime.UtcNow, "1.50","100" },
                    { "DB473C6D-3FB5-44AA-A452-E4231071A6BF", "Arroz",DateTime.UtcNow, "10.00","200" },
                    { "33D34134-8D39-4AC5-93D6-9927C9C2FB80", "Feijão",DateTime.UtcNow, "8.50","300" },
                });

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
