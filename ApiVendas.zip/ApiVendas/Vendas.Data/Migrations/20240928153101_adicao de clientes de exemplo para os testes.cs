﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Vendas.Data.Migrations
{
    /// <inheritdoc />
    public partial class adicaodeclientesdeexemploparaostestes : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "clientes",
                columns: new[] { "id", "nome", "data_criacao" },
                values: new object[,]
                {
                    { "5B052BB8-781A-4E9A-AA37-28B7E271CFD3", "Paulo",DateTime.UtcNow },
                    { "412F69D7-3F38-497E-A48E-AE73FAD15D51", "Pedro",DateTime.UtcNow },
                    { "442FBB62-930D-436D-9C63-ECFB93E7103E", "Maria",DateTime.UtcNow },
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
