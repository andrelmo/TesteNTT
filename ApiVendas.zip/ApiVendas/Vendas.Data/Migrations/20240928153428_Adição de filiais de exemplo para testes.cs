﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Vendas.Data.Migrations
{
    /// <inheritdoc />
    public partial class Adiçãodefiliaisdeexemploparatestes : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "filiais",
                columns: new[] { "id", "nome", "data_criacao" },
                values: new object[,]
                {
                    { "DBD5635F-0385-44B0-A84A-7DDD320F9D3D", "Filial de Belo Horizonte",DateTime.UtcNow },
                    { "7ED488DE-2695-4FDA-86CD-CE9EF9361070", "Filial de São Paulo",DateTime.UtcNow },
                    { "05DE312C-D7B9-48E2-A9EF-D8189B7E7B92", "Filial de Rio de Janeiro",DateTime.UtcNow },
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
