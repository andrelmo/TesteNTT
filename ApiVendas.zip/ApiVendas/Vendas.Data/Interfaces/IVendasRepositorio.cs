﻿using Vendas.Data.Filters;
using Vendas.Domain.Entities;

namespace Vendas.Data.Interfaces
{
    public interface IVendasRepositorio
    {
        Task<PaginatedEntity<VendaEntidade>> BuscarTodoAsync(VendasFilter filter, CancellationToken cancellationToken);
        Task<VendaEntidade> InserirAsync(VendaEntidade venda, CancellationToken cancellationToken);
        Task<VendaEntidade> AtualizarAsync(VendaEntidade venda, CancellationToken cancellationToken);
        Task<VendaEntidade> DeletarAsync(VendaEntidade venda, CancellationToken cancellationToken);
        Task<VendaEntidade> BuscarPorId(Guid id, CancellationToken cancellationToken);
    }
}