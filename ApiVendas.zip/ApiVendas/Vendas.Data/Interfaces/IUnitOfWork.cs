﻿namespace Vendas.Data.Interfaces
{
    public interface IUnitOfWork
    {
        Task Commit();
        Task Rollback();
        Task BeginTransaction();
    }
}