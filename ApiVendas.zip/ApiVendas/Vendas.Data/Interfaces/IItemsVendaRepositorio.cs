﻿using Vendas.Domain.Entities;

namespace Vendas.Data.Interfaces
{
    public interface IItemsVendaRepositorio
    {
        Task<bool> InserirAsync(List<ItemVendaEntidade> itemsVenda, CancellationToken cancellationToken);
        Task<ItemVendaEntidade> AtualizarAsync(ItemVendaEntidade itemVenda, CancellationToken cancellationToken);
        bool DeletarRange(List<ItemVendaEntidade> itemsVenda, CancellationToken cancellationToken);
    }
}