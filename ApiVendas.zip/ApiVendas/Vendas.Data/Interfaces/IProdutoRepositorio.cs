﻿using Vendas.Domain.Entities;

namespace Vendas.Data.Interfaces
{
    public interface IProdutoRepositorio
    {
        Task<ProdutoEntidade> AtualizarAsync(ProdutoEntidade produto, CancellationToken cancellationToken);
        Task<ProdutoEntidade> BuscaPorIdAsync(Guid id, CancellationToken cancellationToken);
    }
}