﻿using Microsoft.EntityFrameworkCore;
using System.Reflection;
using Vendas.Domain.Entities;

namespace Vendas.Data
{
    public class VendasContext: DbContext
    {
        public DbSet<ClienteEntidade> Clientes { get; set; }
        public DbSet<FilialEntidade> Filiais { get; set; }
        public DbSet<ItemVendaEntidade> ItemsVenda { get; set; }
        public DbSet<ProdutoEntidade> Produtos { get; set; }
        public DbSet<VendaEntidade> Vendas { get; set; }

        public VendasContext(DbContextOptions<VendasContext> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
        }
    }
}