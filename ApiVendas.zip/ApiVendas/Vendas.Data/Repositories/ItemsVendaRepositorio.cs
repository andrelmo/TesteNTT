﻿using Vendas.Data.Interfaces;
using Vendas.Domain.Entities;

namespace Vendas.Data.Repositories
{
    public class ItemsVendaRepositorio : IItemsVendaRepositorio
    {
        private readonly VendasContext _context;

        public ItemsVendaRepositorio(VendasContext context)
        {
            _context = context;
        }

        public async Task<bool> InserirAsync(List<ItemVendaEntidade> itemsVenda, CancellationToken cancellationToken)
        {
            if (itemsVenda.Count is 0)
                return false;

            await _context.ItemsVenda.AddRangeAsync(itemsVenda, cancellationToken);

            return true;
        }

        public async Task<ItemVendaEntidade> AtualizarAsync(ItemVendaEntidade itemVenda, CancellationToken cancellationToken)
        {
            _context.ItemsVenda.Update(itemVenda);
            await _context.SaveChangesAsync(cancellationToken);

            return itemVenda;
        }

        public bool DeletarRange(List<ItemVendaEntidade> itemsVenda, CancellationToken cancellationToken)
        {
            if (itemsVenda.Count is 0)
                return false;

            _context.ItemsVenda.RemoveRange(itemsVenda);

            return true;
        }
    }
}