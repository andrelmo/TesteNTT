﻿using Microsoft.EntityFrameworkCore;
using Vendas.Data.Interfaces;
using Vendas.Domain.Entities;

namespace Vendas.Data.Repositories
{
    public class ProdutoRepositorio: IProdutoRepositorio
    {
        private readonly VendasContext _context;

        public ProdutoRepositorio(VendasContext context)
        {
            _context = context;
        }

        public async Task<ProdutoEntidade> AtualizarAsync(ProdutoEntidade produto, CancellationToken cancellationToken)
        {
            _context.Produtos.Update(produto);
            await _context.SaveChangesAsync(cancellationToken);

            return produto;
        }

        public async Task<ProdutoEntidade> BuscaPorIdAsync(Guid id, CancellationToken cancellationToken)
        {
            return await _context.Produtos
                .FirstOrDefaultAsync(x => x.DataDelecao == null && x.Id == id, cancellationToken);
        }
    }
}