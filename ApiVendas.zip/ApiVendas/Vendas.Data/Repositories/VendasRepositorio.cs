﻿using Microsoft.EntityFrameworkCore;
using Vendas.Data.Filters;
using Vendas.Data.Interfaces;
using Vendas.Domain.Entities;

namespace Vendas.Data.Repositories
{
    public class VendasRepositorio : IVendasRepositorio
    {
        private readonly VendasContext _context;

        public VendasRepositorio(VendasContext context)
        {
            _context = context;
        }

        public async Task<PaginatedEntity<VendaEntidade>> BuscarTodoAsync(VendasFilter filter, CancellationToken cancellationToken)
        {
            var query = _context.Vendas
                .Include(x => x.Cliente)
                .Include(x => x.Filial)
                .Include(r => r.Items).ThenInclude(i => i.Produto)
                .AsQueryable();

            query = query.Where(x => x.DataDelecao == null);

            var _dataInicial = new DateTime(filter.DataInicial.Year, filter.DataInicial.Month,
                filter.DataInicial.Day, 0, 0, 0);
            var _dataFinal = new DateTime(filter.DataFinal.Year, filter.DataFinal.Month,
                filter.DataFinal.Day, 23, 59, 59);

            query = query.Where(x => x.DataVenda >= _dataInicial.ToUniversalTime() && x.DataVenda <= _dataFinal.ToUniversalTime());

            var itemsCount = await query.AsNoTracking().CountAsync();

            query = query
                .OrderBy(i => i.Id)
                .Skip((filter.Pagina - 1) * filter.ItemsPorPagina)
                .Take(filter.ItemsPorPagina);

            var items = await query.AsNoTracking().ToListAsync();

            return new PaginatedEntity<VendaEntidade>
            {
                Items = items,
                TotalRegistros = itemsCount
            };
        }

        public async Task<VendaEntidade> InserirAsync(VendaEntidade venda, CancellationToken cancellationToken)
        {
            await _context.Vendas.AddAsync(venda, cancellationToken);
            await _context.SaveChangesAsync(cancellationToken);

            return venda;
        }

        public async Task<VendaEntidade> AtualizarAsync(VendaEntidade venda, CancellationToken cancellationToken)
        {
            _context.Vendas.Update(venda);
            await _context.SaveChangesAsync(cancellationToken);

            return venda;
        }

        public async Task<VendaEntidade> DeletarAsync(VendaEntidade venda, CancellationToken cancellationToken)
        {
            _context.Vendas.Update(venda);
            await _context.SaveChangesAsync(cancellationToken);

            return venda;
        }

        public async Task<VendaEntidade> BuscarPorId(Guid id, CancellationToken cancellationToken)
        {
            return await _context.Vendas
                .Include(r => r.Cliente)
                .Include(r => r.Filial)
                .Include(r => r.Items).ThenInclude(i=> i.Produto)
                .FirstOrDefaultAsync(x => x.DataDelecao == null && x.Id == id, cancellationToken);
        }
    }
}