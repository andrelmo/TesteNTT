﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Vendas.Domain.Entities;

namespace Vendas.Data.Mappers
{
    public class ItemVendaMapper : IEntityTypeConfiguration<ItemVendaEntidade>
    {
        public void Configure(EntityTypeBuilder<ItemVendaEntidade> builder)
        {
            builder.ToTable("item_vendas").HasKey(x => x.Id);
            builder.Property(x => x.Id).IsRequired(true).HasColumnName("id");
            builder.Property(x => x.DataCriacao).IsRequired(true).HasColumnName("data_criacao");
            builder.Property(x => x.DataAtualizacao).HasColumnName("data_atualizacao");
            builder.Property(x => x.DataDelecao).HasColumnName("data_delecao");
            builder.Property(x => x.ProdutoEntidadeId).HasColumnName("produto_id").IsRequired(true);
            builder.Property(x => x.ValorUnitario).HasColumnName("valor_unitario").IsRequired(true);
            builder.Property(x => x.Quantidade).HasColumnName("quantidade").IsRequired(true);
            builder.Property(x => x.Desconto).HasColumnName("desconto").IsRequired(false);
            builder.Property(x => x.VendaEntidadeId).HasColumnName("venda_id").IsRequired(true);
            builder.Property(x => x.Status).HasColumnName("status").HasColumnType("int").IsRequired(true);
        }
    }
}