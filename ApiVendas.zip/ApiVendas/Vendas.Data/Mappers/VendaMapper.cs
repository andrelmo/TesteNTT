﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Vendas.Domain.Entities;

namespace Vendas.Data.Mappers
{
    public class VendaMapper : IEntityTypeConfiguration<VendaEntidade>
    {
        public void Configure(EntityTypeBuilder<VendaEntidade> builder)
        {
            builder.ToTable("vendas").HasKey(x => x.Id);
            builder.Property(x => x.Id).IsRequired(true).HasColumnName("id");
            builder.Property(x => x.DataCriacao).IsRequired(true).HasColumnName("data_criacao");
            builder.Property(x => x.DataAtualizacao).HasColumnName("data_atualizacao");
            builder.Property(x => x.DataDelecao).HasColumnName("data_delecao");
            builder.Property(x => x.DataVenda).HasColumnName("data_venda").IsRequired(true);
            builder.Property(x => x.ClienteEntidadeId).HasColumnName("cliente_id").IsRequired(true);
            builder.Property(x => x.FilialEntidadeId).HasColumnName("filial_id").IsRequired(true);
            builder.Property(x => x.Status).HasColumnName("status").HasColumnType("int").IsRequired(true);
            builder.HasMany(x => x.Items)
                           .WithOne(x => x.Venda)
                           .HasForeignKey(x => x.VendaEntidadeId)
                           .HasConstraintName("rel_item_venda_venda");
        }
    }
}