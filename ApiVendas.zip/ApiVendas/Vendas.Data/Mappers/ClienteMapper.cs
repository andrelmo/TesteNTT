﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Vendas.Domain.Entities;

namespace Vendas.Data.Mappers
{
    public class ClienteMapper : IEntityTypeConfiguration<ClienteEntidade>
    {
        public void Configure(EntityTypeBuilder<ClienteEntidade> builder)
        {
            builder.ToTable("clientes").HasKey(x => x.Id);
            builder.Property(x => x.Id).IsRequired(true).HasColumnName("id");
            builder.Property(x => x.DataCriacao).IsRequired(true).HasColumnName("data_criacao");
            builder.Property(x => x.DataAtualizacao).HasColumnName("data_atualizacao");
            builder.Property(x => x.DataDelecao).HasColumnName("data_delecao");
            builder.Property(x => x.Nome).HasColumnName("nome").HasColumnType("varchar(100)").IsRequired(true);
        }
    }
}