﻿namespace Vendas.Data.Filters
{
    public abstract class BaseFilter
    {
        private const int ITEMS_POR_PAGINA_PADRAO = 10;
        private const int PAGINA_PADRAO = 1;

        public BaseFilter()
        {
            ItemsPorPagina = 10;
            Pagina = 1;
        }

        public int ItemsPorPagina { get; set; }
        public int Pagina { get; set; }
    }
}