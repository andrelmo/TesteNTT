﻿namespace Vendas.Data.Filters
{
    public class VendasFilter: BaseFilter
    {
        public DateTime DataInicial { get; set; }
        public DateTime DataFinal { get; set; }
    }
}