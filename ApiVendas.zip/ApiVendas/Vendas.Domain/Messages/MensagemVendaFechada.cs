﻿namespace Vendas.Domain.Messages
{
    public class MensagemVendaFechada
    {
        public Guid Id { get; set; }
    }
}