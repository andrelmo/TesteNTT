﻿namespace Vendas.Domain.Messages
{
    public class MensagemVendaCancelada
    {
        public Guid Id { get; set; }
    }
}
