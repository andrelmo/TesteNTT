﻿namespace Vendas.Domain.Messages
{
    public class MensagemVendaCriada
    {
        public Guid Id { get; set; }
        public Guid ClienteEntidadeId { get; set; }
        public DateTime DataVenda { get; set; }
        public Guid FilialEntidadeId { get; set; }
        public List<ObjetoItemVenda> Items { get; set; }
    }
}