﻿using FluentValidation.Results;
using Vendas.ControllerHandler.ValueObjects;

namespace Vendas.Domain.Errors
{
    public class ValidationError : Error
    {
        public ValidationError(List<ValidationFailure> validations)
        {
            var errors = validations.Select(x => $"{x.PropertyName} - {x.ErrorMessage}");
            Message = string.Join(", ", errors);
        }
    }
}