﻿using Vendas.ControllerHandler.ValueObjects;

namespace Vendas.Domain.Errors
{
    public class QuantidadeInsuficienteError : Error
    {
        public QuantidadeInsuficienteError(string message)
        {
            Message = message ?? "A quantidade informada é superior ao disponível";
        }
    }
}