﻿using Vendas.ControllerHandler.ValueObjects;

namespace Vendas.Domain.Errors
{
    public class UnknownError : Error
    {
        public UnknownError(string message)
        {
            Message = message;
        }
    }
}
