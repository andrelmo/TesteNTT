﻿using Vendas.ControllerHandler.ValueObjects;

namespace Vendas.Domain.Errors
{
    public class NoRecordsError : Error
    {
        public NoRecordsError(string message)
        {
            Message = message ?? "Dados não localizados";
        }
    }
}