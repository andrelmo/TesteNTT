﻿namespace Vendas.Domain.Enums
{
    public enum StatusItemVenda
    {
        SIVCancelado = 1,
        SIVNaoCancelado = 2
    }
}