﻿namespace Vendas.Domain.Enums
{
    public enum StatusVenda
    {
        SVCriada = 1,
        SVCancelada = 2,
        SVFechada = 3,
    }
}