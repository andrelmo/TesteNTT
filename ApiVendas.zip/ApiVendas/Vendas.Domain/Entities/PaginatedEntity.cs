﻿namespace Vendas.Domain.Entities
{
    public class PaginatedEntity<T>
    {
        public IEnumerable<T> Items { get; set; }
        public int TotalRegistros { get; set; }
    }
}