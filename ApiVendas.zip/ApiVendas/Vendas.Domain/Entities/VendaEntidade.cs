﻿using Vendas.Domain.Enums;

namespace Vendas.Domain.Entities
{
    public class VendaEntidade: BaseEntidade<Guid>
    {
        public DateTime DataVenda { get; set; }
        public Guid ClienteEntidadeId { get; set; }
        public ClienteEntidade Cliente { get; set; }
        public Guid FilialEntidadeId { get; set; }
        public FilialEntidade Filial { get; set; }
        public List<ItemVendaEntidade> Items { get; set; }
        public StatusVenda Status { get; set; }

        public VendaEntidade(): base() 
        {
            this.Create();
        }
    }
}