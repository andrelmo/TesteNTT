﻿namespace Vendas.Domain.Entities
{
    public class ClienteEntidade: BaseEntidade<Guid>
    {
        public string Nome { get; set; }
    }
}