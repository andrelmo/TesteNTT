﻿namespace Vendas.Domain.Entities
{
    public abstract class BaseEntidade<T>
    {
        public T Id { get; set; }
        public DateTime DataCriacao { get; private set; }
        public DateTime? DataAtualizacao { get; private set; } = DateTime.UtcNow;
        public DateTime? DataDelecao { get; private set; }

        public void Create()
        {
            DataCriacao = DateTime.UtcNow;
        }

        public void Delete()
        {
            DataDelecao = DateTime.UtcNow;
        }

        public void Update()
        {
            DataAtualizacao = DateTime.UtcNow;
        }
    }
}