﻿namespace Vendas.Domain.Entities
{
    public class ProdutoEntidade: BaseEntidade<Guid>
    {
        public string Nome { get; set; }
        public decimal ValorUnitario { get; set; }
        public int Quantidade { get; set; }
    }
}