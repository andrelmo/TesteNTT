﻿namespace Vendas.Domain.Entities
{
    public class FilialEntidade: BaseEntidade<Guid>
    {
        public string Nome { get; set; }
    }
}