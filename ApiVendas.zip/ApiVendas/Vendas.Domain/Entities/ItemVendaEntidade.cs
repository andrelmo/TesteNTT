﻿using Vendas.Domain.Enums;

namespace Vendas.Domain.Entities
{
    public class ItemVendaEntidade: BaseEntidade<Guid>
    {
        public Guid ProdutoEntidadeId { get; set; }
        public ProdutoEntidade Produto { get; set; }
        public decimal ValorUnitario { get; set; }
        public int Quantidade { get; set; }
        public decimal? Desconto { get; set; }
        public Guid VendaEntidadeId { get; set; }
        public VendaEntidade Venda { get; set; }
        public StatusItemVenda Status { get; set; }

        public ItemVendaEntidade(): base()
        {
            this.Create();
        }
    }
}