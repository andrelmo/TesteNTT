﻿using Microsoft.AspNetCore.Mvc;
using Vendas.ControllerHandler.ValueObjects;
using Vendas.Domain.Errors;

namespace Vendas.Domain.Extensions
{
    public static class ErrorExtension
    {
        public static IActionResult ToHttpResponseError(this Error error) => error switch
        {
            NotFoundError => new NotFoundObjectResult(error),
            NoRecordsError => new OkObjectResult(error),
            _ => new BadRequestObjectResult(error),
        };
    }
}
