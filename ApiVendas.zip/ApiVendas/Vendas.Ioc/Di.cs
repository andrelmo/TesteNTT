﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using RestSharp;
using Vendas.Application.Interfaces;
using Vendas.Application.Services;
using Vendas.Data;
using Vendas.Data.Interfaces;
using Vendas.Data.Repositories;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace Vendas.Ioc
{
    public static class DI
    {
        public static void AddServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.TryAddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddSingleton<IRestClient>(serviceProvider =>
            {
                var clientOptions = new RestClientOptions()
                {
                };

                return new RestClient(clientOptions);
            });

            services.AddSingleton(configuration);
            services.AddTransient<IUnitOfWork, UnitOfWork>();

            var path = Path.Combine(Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) ?? "", "p4edcom.crt");

            services.AddDbContext<VendasContext>(options => options.UseNpgsql(configuration["CONNECTION_STRING"]).EnableDetailedErrors());
            services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
            services.AddScoped<IProdutoRepositorio, ProdutoRepositorio>();
            services.AddScoped<IItemsVendaRepositorio, ItemsVendaRepositorio>();
            services.AddScoped<IVendasRepositorio, VendasRepositorio>();
            services.AddScoped<IVendasServico, VendasServico>();
            services.AddScoped<IClientServiceBus, ClientServiceBus>();
        }
    }
}