﻿using Vendas.Application.Dtos.Request;
using Vendas.Application.Dtos.Response;
using Vendas.ControllerHandler.ValueObjects;
using Vendas.Data.Filters;

namespace Vendas.Application.Interfaces
{
    public interface IVendasServico
    {
        Task<Result<VendaResponse>> BuscarPorIdAsync(Guid id, CancellationToken cancellationToken);
        Task<Result<VendaDataResponse>> BuscarTodosAsync(VendasFilter filter, CancellationToken cancellationToken);
        Task<Result<CreateVendaResponse>> CriarAsync(CriarVendaRequest request, CancellationToken cancellationToken);
        Task<Result<CancelarVendaResponse>> CancelarAsync(CancelarVendaRequest request, CancellationToken cancellationToken);
        Task<Result<FecharVendaResponse>> FecharAsync(FecharVendaRequest request, CancellationToken cancellationToken);
    }
}
