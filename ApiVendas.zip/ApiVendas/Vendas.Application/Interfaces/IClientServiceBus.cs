﻿using Vendas.Domain.Messages;

namespace Vendas.Application.Interfaces
{
    public interface IClientServiceBus
    {
        Task EnviarMensagemAsync(MensagemVendaCriada venda);
        Task EnviarMensagemAsync(MensagemVendaCancelada venda);
        Task EnviarMensagemAsync(MensagemVendaFechada venda);
    }
}