﻿using AutoMapper;
using Vendas.Application.Dtos.Response;
using Vendas.Domain.Entities;

namespace Vendas.Application.AutoMapper
{
    public class VendasMappingProfile : Profile
    {
        public VendasMappingProfile()
        {
            CreateMap<ClienteEntidade, ClienteResponse>();
            CreateMap<FilialEntidade, FilialResponse>();
            CreateMap<ProdutoEntidade, ProdutoResponse>();
            CreateMap<ItemVendaEntidade, ItemVendaResponse>();
            CreateMap<VendaEntidade, VendaResponse>();
            CreateMap<VendaEntidade, CreateVendaResponse>();
            CreateMap<VendaEntidade, CancelarVendaResponse>();
            CreateMap<VendaEntidade, FecharVendaResponse>();

        }
    }
}