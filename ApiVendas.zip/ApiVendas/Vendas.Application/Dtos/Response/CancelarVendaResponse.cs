﻿namespace Vendas.Application.Dtos.Response
{
    public class CancelarVendaResponse
    {
        public Guid Id { get; set; }
    }
}