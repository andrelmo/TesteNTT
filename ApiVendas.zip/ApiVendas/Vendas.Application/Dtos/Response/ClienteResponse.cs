﻿namespace Vendas.Application.Dtos.Response
{
    public class ClienteResponse
    {
        public Guid Id { get; set; }
        public string Nome { get; set; }
    }
}