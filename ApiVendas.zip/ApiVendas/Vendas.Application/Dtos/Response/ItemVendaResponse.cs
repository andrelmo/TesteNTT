﻿namespace Vendas.Application.Dtos.Response
{
    public class ItemVendaResponse
    {
        public Guid Id { get; set; }
        public Guid ProdutoEntidadeId { get; set; }
        public ProdutoResponse Produto { get; set; }
        public decimal ValorUnitario { get; set; }
        public int Quantidade { get; set; }
        public decimal? Desconto { get; set; }
        public decimal ValorTotal { get; set; }
    }
}