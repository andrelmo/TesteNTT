﻿namespace Vendas.Application.Dtos.Response
{
    public class VendaResponse
    {
        public Guid Id { get; set; }
        public DateTime DataVenda { get; set; }
        public Guid ClienteEntidadeId { get; set; }
        public ClienteResponse Cliente { get; set; }
        public Guid FilialEntidadeId { get; set; }
        public FilialResponse Filial { get; set; }
        public List<ItemVendaResponse> Items { get; set; }
        public decimal ValorTotal { get; set; }
    }
}