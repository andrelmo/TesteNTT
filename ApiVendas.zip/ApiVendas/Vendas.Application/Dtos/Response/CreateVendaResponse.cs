﻿namespace Vendas.Application.Dtos.Response
{
    public class CreateVendaResponse
    {
        public Guid Id { get; set; }
    }
}