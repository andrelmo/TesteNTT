﻿namespace Vendas.Application.Dtos.Response
{
    public class FilialResponse
    {
        public Guid Id { get; set; }
        public string Nome { get; set; }
    }
}