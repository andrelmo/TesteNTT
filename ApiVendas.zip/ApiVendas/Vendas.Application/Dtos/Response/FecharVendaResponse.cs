﻿namespace Vendas.Application.Dtos.Response
{
    public class FecharVendaResponse
    {
        public Guid Id { get; set; }
    }
}