﻿namespace Vendas.Application.Dtos.Response
{
    public class VendaDataResponse
    {
        public List<VendaResponse>? Data { get; set; }
        public int TotalRegistros { get; set; }
    }
}