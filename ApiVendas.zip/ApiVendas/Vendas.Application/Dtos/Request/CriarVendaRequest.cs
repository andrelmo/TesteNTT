﻿namespace Vendas.Application.Dtos.Request
{
    public class CriarVendaRequest
    {
        public DateTime DataVenda { get; set; }
        public Guid ClienteId { get; set; }
        public Guid FilialId { get; set; }
        public List<ItemVendaRequest> Items { get; set; } = new List<ItemVendaRequest>();
    }
}