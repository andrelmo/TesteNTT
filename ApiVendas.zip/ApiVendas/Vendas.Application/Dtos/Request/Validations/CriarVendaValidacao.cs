﻿using FluentValidation;

namespace Vendas.Application.Dtos.Request.Validations
{
    public class CriarVendaValidacao: AbstractValidator<CriarVendaRequest>
    {
        public CriarVendaValidacao()
        {
            RuleFor(x => x.Items)
                .NotEmpty()
                .When(x => x.Items is null || x.Items.Count() == 0)
                .WithMessage("A lista de item deve ter pelo menos um registro.");
        }
    }
}