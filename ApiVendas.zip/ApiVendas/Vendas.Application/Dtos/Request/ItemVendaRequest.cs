﻿namespace Vendas.Application.Dtos.Request
{
    public class ItemVendaRequest
    {
        public Guid ProdutoId { get; set; }
        public decimal ValorUnitario { get; set; }
        public int Quantidade { get; set; }
        public decimal? Desconto { get; set; }
    }
}