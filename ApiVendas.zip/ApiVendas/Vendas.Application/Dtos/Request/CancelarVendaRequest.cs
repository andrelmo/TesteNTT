﻿namespace Vendas.Application.Dtos.Request
{
    public class CancelarVendaRequest
    {
        public Guid Id { get; set; }
    }
}