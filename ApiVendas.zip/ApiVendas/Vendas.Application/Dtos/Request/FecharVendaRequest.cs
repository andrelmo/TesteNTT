﻿namespace Vendas.Application.Dtos.Request
{
    public class FecharVendaRequest
    {
        public Guid Id { get; set; }
    }
}