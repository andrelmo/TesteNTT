﻿using Azure.Messaging.ServiceBus;
using Microsoft.Extensions.Configuration;
using System.Text.Json;
using Vendas.Application.Interfaces;
using Vendas.Domain.Messages;

namespace Vendas.Application.Services
{
    public class ClientServiceBus: IClientServiceBus
    {
        private readonly ServiceBusClient _client;
        private readonly ServiceBusSender _senderFilaCompradaCriada;
        private readonly ServiceBusSender _senderFilaCompradaCancelada;
        private readonly ServiceBusSender _senderFilaCompradaFechada;
        private readonly IConfiguration _configuration;
        private readonly string _connectionString;
        public ClientServiceBus(IConfiguration configuration)
        {
            _configuration = configuration;
            _connectionString = configuration["ServiceBusEndPoint"];
            _client = new ServiceBusClient(_connectionString);
            _senderFilaCompradaCriada = _client.CreateSender("compradacriada");
            _senderFilaCompradaCancelada = _client.CreateSender("compracancelada");
            _senderFilaCompradaFechada = _client.CreateSender("comprafechada");
       }

        public async Task EnviarMensagemAsync(MensagemVendaCriada venda)
        {
            try
            {
                // Serializa a mensagem para JSON
                string mensagemJson = JsonSerializer.Serialize(venda);

                // Cria uma mensagem do Service Bus
                ServiceBusMessage mensagem = new ServiceBusMessage(mensagemJson);

                // Envia a mensagem para a fila
                await _senderFilaCompradaCriada.SendMessageAsync(mensagem);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                // Limpa os recursos
                await _senderFilaCompradaCriada.DisposeAsync();
                await _client.DisposeAsync();
            }
        }

        public async Task EnviarMensagemAsync(MensagemVendaCancelada venda)
        {
            try
            {
                // Serializa a mensagem para JSON
                string mensagemJson = JsonSerializer.Serialize(venda);

                // Cria uma mensagem do Service Bus
                ServiceBusMessage mensagem = new ServiceBusMessage(mensagemJson);

                // Envia a mensagem para a fila
                await _senderFilaCompradaCancelada.SendMessageAsync(mensagem);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                // Limpa os recursos
                await _senderFilaCompradaCriada.DisposeAsync();
                await _client.DisposeAsync();
            }
        }

        public async Task EnviarMensagemAsync(MensagemVendaFechada venda)
        {
            try
            {
                // Serializa a mensagem para JSON
                string mensagemJson = JsonSerializer.Serialize(venda);

                // Cria uma mensagem do Service Bus
                ServiceBusMessage mensagem = new ServiceBusMessage(mensagemJson);

                // Envia a mensagem para a fila
                await _senderFilaCompradaFechada.SendMessageAsync(mensagem);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                // Limpa os recursos
                await _senderFilaCompradaCriada.DisposeAsync();
                await _client.DisposeAsync();
            }
        }
    }
}