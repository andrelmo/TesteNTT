﻿using AutoMapper;
using Microsoft.Extensions.Logging;
using System.Runtime.CompilerServices;
using Vendas.Application.Dtos.Request;
using Vendas.Application.Dtos.Request.Validations;
using Vendas.Application.Dtos.Response;
using Vendas.Application.Interfaces;
using Vendas.ControllerHandler.ValueObjects;
using Vendas.Data.Filters;
using Vendas.Data.Interfaces;
using Vendas.Domain.Entities;
using Vendas.Domain.Errors;
using Vendas.Domain.Messages;

namespace Vendas.Application.Services
{
    public class VendasServico : IVendasServico
    {
        private readonly IMapper _mapper;
        private readonly ILogger _logger;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IVendasRepositorio _vendasRepository;
        private readonly IProdutoRepositorio _produtoRepository;
        private readonly IItemsVendaRepositorio _itemsVendaRepositorio;
        private readonly IClientServiceBus _clientServiceBus;

        public VendasServico(IMapper mapper,
            ILoggerFactory loggerFactory,
            IUnitOfWork unitOfWork,
            IVendasRepositorio vendasRepository,
            IProdutoRepositorio produtoRepository,
            IItemsVendaRepositorio itemsVendaRepositorio,
            IClientServiceBus clientServiceBus)
        {
            _mapper = mapper;
            _logger = loggerFactory.CreateLogger<VendasServico>();
            _unitOfWork = unitOfWork;
            _vendasRepository = vendasRepository;
            _produtoRepository = produtoRepository;
            _itemsVendaRepositorio = itemsVendaRepositorio;
            _clientServiceBus = clientServiceBus;
        }

        public async Task<Result<VendaResponse>> BuscarPorIdAsync(Guid id, CancellationToken cancellationToken)
        {
            var vendasFound = await _vendasRepository.BuscarPorId(id, cancellationToken);

            if (vendasFound is null)
                return Result<VendaResponse>.Failure(new NoRecordsError("Não foi encontrada nenhuma venda com o Id informado"));

            var result = _mapper.Map<VendaResponse>(vendasFound);

            foreach (var item in result.Items)
            {
                decimal _total = 0;

                _total = (item.Quantidade * item.ValorUnitario);
                if (item.Desconto.HasValue)
                    _total = _total - item.Desconto.Value;

                item.ValorTotal = _total;
                result.ValorTotal = result.ValorTotal + item.ValorTotal;
            }

            return Result<VendaResponse>.Success(result);
        }

        public async Task<Result<VendaDataResponse>> BuscarTodosAsync(VendasFilter filter, CancellationToken cancellationToken)
        {
            var vendasFound = await _vendasRepository.BuscarTodoAsync(filter, cancellationToken);

            if (vendasFound.TotalRegistros is 0)
                return Result<VendaDataResponse>.Failure(new NoRecordsError("Não foi encontrada nenhuma venda"));

            var mapped = _mapper.Map<List<VendaResponse>>(vendasFound.Items);

            foreach (var venda in mapped)
            {
                foreach (var item in venda.Items)
                {
                    decimal _total = 0;

                    _total = (item.Quantidade * item.ValorUnitario);
                    if (item.Desconto.HasValue)
                        _total = _total - item.Desconto.Value;

                    item.ValorTotal = _total;
                    venda.ValorTotal = venda.ValorTotal + item.ValorTotal;
                }
            }

            var result = new VendaDataResponse
            {
                Data = mapped,
                TotalRegistros = vendasFound.TotalRegistros,
            };

            return Result<VendaDataResponse>.Success(result);
        }

        public async Task<Result<CreateVendaResponse>> CriarAsync(CriarVendaRequest request, CancellationToken cancellationToken)
        {
            try
            {
                var validation = await new CriarVendaValidacao().ValidateAsync(request, cancellationToken);

                if (!validation.IsValid)
                    return Result<CreateVendaResponse>.Failure(new ValidationError(validation.Errors));

                var venda = CriarVenda(request);

                try
                {
                    foreach (var item in venda.Items)
                    {
                        var _produto = await _produtoRepository.BuscaPorIdAsync(item.ProdutoEntidadeId, cancellationToken);

                        if (_produto.Quantidade < item.Quantidade)
                            return Result<CreateVendaResponse>.Failure(new QuantidadeInsuficienteError("A quantidade informada  é superior ao disponível"));
                    }

                    await _unitOfWork.BeginTransaction();
                    venda = await _vendasRepository.InserirAsync(venda, cancellationToken);

                    foreach (var item in venda.Items)
                    {
                        var _produto = await _produtoRepository.BuscaPorIdAsync(item.ProdutoEntidadeId, cancellationToken);

                        _produto.Quantidade = _produto.Quantidade - item.Quantidade;
                        await _produtoRepository.AtualizarAsync(_produto, cancellationToken);
                    }

                    await _unitOfWork.Commit();

                    var _mensagemVendaCriada = CriarMensagemVendaCriada(request, venda.Id);
                    await _clientServiceBus.EnviarMensagemAsync(_mensagemVendaCriada);

                    var result = _mapper.Map<CreateVendaResponse>(venda);

                    return Result<CreateVendaResponse>.Success(result);
                }
                catch (Exception ex)
                {
                    await _unitOfWork.Rollback();
                    return Result<CreateVendaResponse>.Failure(new UnknownError(ex.Message));
                }
            }
            catch (Exception ex)
            {
                return Result<CreateVendaResponse>.Failure(new UnknownError(ex.Message));
            }
        }

        public async Task<Result<CancelarVendaResponse>> CancelarAsync(CancelarVendaRequest request, CancellationToken cancellationToken)
        {
            try
            {
                var venda = await _vendasRepository.BuscarPorId(request.Id, cancellationToken);

                try
                {
                    await _unitOfWork.BeginTransaction();
                    venda.Update();
                    venda.Status = Domain.Enums.StatusVenda.SVCancelada;

                    foreach (var item in venda.Items)
                    {
                        var _produto = await _produtoRepository.BuscaPorIdAsync(item.ProdutoEntidadeId, cancellationToken);

                        _produto.Quantidade = _produto.Quantidade + item.Quantidade;
                        item.Status = Domain.Enums.StatusItemVenda.SIVCancelado;

                        await _produtoRepository.AtualizarAsync(_produto, cancellationToken);
                        await _itemsVendaRepositorio.AtualizarAsync(item, cancellationToken);
                    }

                    await _vendasRepository.AtualizarAsync(venda, cancellationToken);
                    await _unitOfWork.Commit();

                    var _mensagemVendaCancelada = CriarMensagemVendaCancelada(request.Id);
                    await _clientServiceBus.EnviarMensagemAsync(_mensagemVendaCancelada);

                    var result = _mapper.Map<CancelarVendaResponse>(venda);

                    return Result<CancelarVendaResponse>.Success(result);
                }
                catch (Exception ex)
                {
                    await _unitOfWork.Rollback();
                    return Result<CancelarVendaResponse>.Failure(new UnknownError(ex.Message));
                }
            }
            catch (Exception ex)
            {
                return Result<CancelarVendaResponse>.Failure(new UnknownError(ex.Message));
            }
        }

        public async Task<Result<FecharVendaResponse>> FecharAsync(FecharVendaRequest request, CancellationToken cancellationToken)
        {
            try
            {
                var venda = await _vendasRepository.BuscarPorId(request.Id, cancellationToken);

                try
                {
                    await _unitOfWork.BeginTransaction();
                    venda.Update();
                    venda.Status = Domain.Enums.StatusVenda.SVFechada;
                    await _vendasRepository.AtualizarAsync(venda, cancellationToken);
                    await _unitOfWork.Commit();

                    var _mensagemVendaFechada = CriarMensagemVendaFechada(request.Id);
                    await _clientServiceBus.EnviarMensagemAsync(_mensagemVendaFechada);

                    var result = _mapper.Map<FecharVendaResponse>(venda);

                    return Result<FecharVendaResponse>.Success(result);
                }
                catch (Exception ex)
                {
                    await _unitOfWork.Rollback();
                    return Result<FecharVendaResponse>.Failure(new UnknownError(ex.Message));
                }
            }
            catch (Exception ex)
            {
                return Result<FecharVendaResponse>.Failure(new UnknownError(ex.Message));
            }
        }

        private MensagemVendaFechada CriarMensagemVendaFechada(Guid id)
        {
            return new MensagemVendaFechada()
            {
                Id = id
            };
        }

        private MensagemVendaCancelada CriarMensagemVendaCancelada(Guid id)
        {
            return new MensagemVendaCancelada()
            {
                Id = id
            };
        }

        private MensagemVendaCriada CriarMensagemVendaCriada(CriarVendaRequest request, Guid id)
        {
            var _mensagem = new MensagemVendaCriada()
            {
                ClienteEntidadeId = request.ClienteId,
                DataVenda = request.DataVenda,
                FilialEntidadeId = request.FilialId,
                Id = id,
                Items = new List<ObjetoItemVenda>()
            };

            foreach (var item in request.Items)
            {
                _mensagem.Items.Add(new ObjetoItemVenda()
                {
                    Desconto = item.Desconto,
                    ProdutoEntidadeId = item.ProdutoId,
                    Quantidade = item.Quantidade,
                    Status = Domain.Enums.StatusItemVenda.SIVNaoCancelado,
                    ValorUnitario = item.ValorUnitario,
                });
            }

            return _mensagem;
        }

        private VendaEntidade CriarVenda(CriarVendaRequest request)
        {
            var venda = new VendaEntidade()
            {
                Id = Guid.NewGuid(),
                ClienteEntidadeId = request.ClienteId,
                DataVenda = request.DataVenda.ToUniversalTime(),
                FilialEntidadeId = request.FilialId,
                Status = Domain.Enums.StatusVenda.SVCriada,
                Items = new List<ItemVendaEntidade>()
            };

            foreach (var item in request.Items)
            {
                var itemVenda = new ItemVendaEntidade()
                {
                    Id = Guid.NewGuid(),
                    Desconto = item.Desconto,
                    ProdutoEntidadeId = item.ProdutoId,
                    Quantidade = item.Quantidade,
                    Status = Domain.Enums.StatusItemVenda.SIVNaoCancelado,
                    ValorUnitario = item.ValorUnitario
                };

                venda.Items.Add(itemVenda);
            }

            return (venda);
        }
    }
}